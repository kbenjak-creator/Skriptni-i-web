/* const stvara spremmnik podataka; canvas je ime naše konstante; document.getel... je metoda pomoću
koje pristupamo elementu iz html dokumenta */

const canvas = document.getElementById("platno");

/* 2D OZNACAVA DVODIMENZIONALNO CRTANJE */
const ctx = canvas.getContext("2d");


/* nije metoda jer nema (); svojstvo koje mjenja ispunu oblika */
ctx.fillStyle = "pink";


/* mjenja obrub oblika */
ctx.strokeStyle = "purple";

/* postavlja debljinu obruba */
ctx.lineWidth = 5;

/* Ova metoda kreira pravokutnik ali bez ispune */
ctx.strokeRect(50,60,50,50);


/* metoda koja kreira crni pravokutniik; 50 je X, 60 je Y, 200 je širina, 150 je visina*/
ctx.fillRect(50,60,50,50);
ctx.fillRect(200,100,50,50);

ctx.fillStyle ="red";
ctx.fillRect(300,150,50,50);

//crtanje linije *//
ctx.beginPath();
/*Postavlja poćetnu poziciju */
ctx.moveTo(50,50);
/* definira liniju od počet poz. do zadane točke */
ctx.lineTo(300,200)
/* Iscrtava putanju */
ctx.stroke();

/* Više povezanih crta */
ctx.beginPath();
ctx.moveTo(100,300);
ctx.lineTo(200,200);
ctx.lineTo(300,300);

/* zatvara putanju */
ctx.closePath();
ctx.stroke();

ctx.fillStyle ="blue";
ctx.fill();

ctx.strokeStyle ="green"
ctx.stroke();

/* crtanje kruga */
ctx.beginPath();
ctx.arc(300,200,80,0,2*Math.PI);
ctx.strokeStyle ="purple";
ctx.stroke();

ctx.fillStyle ="orange";
ctx.fill();

ctx.beginPath();
ctx.arc(500,300,80,0,Math.PI);
ctx.strokeStyle ="indigo";
ctx.stroke();

/* dodavanje teksta */
ctx.font ="30px Arial"
ctx.fillStyle ="yellow"
ctx.fillText("Karlo Benjak",250,250);
