const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");


ctx.fillStyle = "orange";
ctx.fillRect(180, 180, 240, 150);


ctx.strokeStyle = "black";
ctx.lineWidth = 3;
ctx.strokeRect(180, 180, 240, 150);


ctx.fillStyle = "brown";
ctx.fillRect(275, 250, 50, 80);


ctx.strokeStyle = "black";
ctx.strokeRect(275, 250, 50, 80);


ctx.fillStyle = "lightblue";
ctx.fillRect(210, 220, 50, 50);

ctx.strokeStyle = "black";
ctx.strokeRect(210, 220, 50, 50);


ctx.fillStyle = "lightblue";
ctx.fillRect(340, 220, 50, 50);

ctx.strokeStyle = "black";
ctx.strokeRect(340, 220, 50, 50);


ctx.beginPath();
ctx.moveTo(160, 180);
ctx.lineTo(300, 80);
ctx.lineTo(440, 180);
ctx.closePath();

ctx.fillStyle = "red";
ctx.fill();

ctx.strokeStyle = "black";
ctx.lineWidth = 3;
ctx.stroke();


ctx.beginPath();
ctx.arc(500, 80, 40, 0, 2 * Math.PI);

ctx.fillStyle = "yellow";
ctx.fill();


ctx.fillStyle = "black";
ctx.font = "24px Arial";
ctx.fillText("Moja kuća", 240, 370);
